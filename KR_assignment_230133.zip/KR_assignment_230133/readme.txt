CONTENTS OF THIS FILE
---------------------

 * Introduction
This is the project of G6019 Konwledge & Reasoning. 
Open the Checkers game file and run main.py can play this simple game with AI.

 * Requirements
pc with Python 3.8 and pygame 2.0.2
